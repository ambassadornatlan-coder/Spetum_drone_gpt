
const t={en:['Intelligence in the Air. Precision on the Ground.','Advanced Geospatial Intelligence, Sensor Integration and Fixed‑Wing UAV Solutions.'],
cz:['Inteligence ve vzduchu. Přesnost na zemi.','Pokročilé geoprostorové technologie, integrace senzorů a řešení UAV.']};
enBtn.onclick=()=>{heroTitle.innerText=t.en[0];heroSub.innerText=t.en[1];}
czBtn.onclick=()=>{heroTitle.innerText=t.cz[0];heroSub.innerText=t.cz[1];}
